/*
 * SPDX-License-Identifier: Apache-2.0
 */
import { Context, Contract, Info, Returns, Transaction } from 'fabric-contract-api';
import { ClientIdentity, Iterators } from 'fabric-shim';
import { Car } from './car';
import { ChangeOwnerEvent } from './event';
// import { Timestamp } from 'google-protobuf/google/protobuf/timestamp_pb';
// import { Timestamp } from 'proto.google.protobuf.Timestamp';
import { PreviousOwnersResult } from './previousOwners';
import { TimestampMapper } from './timestamp';
import { Utils } from './utils';

@Info({ title: 'FabCar', description: 'FabCar Smart Contract' })
export class FabCar extends Contract {

  // @Transaction(false)
  public async initLedger(ctx: Context) {
    console.info('============= START : Initialize Ledger ===========');

    // get our ID to stamp into the car
    const cid = new ClientIdentity(ctx.stub);
    const clientCertId = cid.getID();

    const cars: Car[] = [
      {
        color: 'blue',
        make: 'Toyota',
        model: 'Prius',
        owner: 'Tomoko',
      },
      {
        color: 'red',
        make: 'Ford',
        model: 'Mustang',
        owner: 'Brad',
      },
      {
        color: 'green',
        make: 'Hyundai',
        model: 'Tucson',
        owner: 'Jin Soo',
      },
      {
        color: 'yellow',
        make: 'Volkswagen',
        model: 'Passat',
        owner: 'Max',
      },
      {
        color: 'black',
        make: 'Tesla',
        model: 'S',
        owner: 'Adriana',
      },
      {
        color: 'purple',
        make: 'Peugeot',
        model: '205',
        owner: 'Michel',
      },
      {
        color: 'white',
        make: 'Chery',
        model: 'S22L',
        owner: 'Aarav',
      },
      {
        color: 'violet',
        make: 'Fiat',
        model: 'Punto',
        owner: 'Pari',
      },
      {
        color: 'indigo',
        make: 'Tata',
        model: 'Nano',
        owner: 'Valeria',
      },
      {
        color: 'brown',
        make: 'Holden',
        model: 'Barina',
        owner: 'Shotaro',
      },
    ];

    for (let i = 0; i < cars.length; i++) {
      cars[i].docType = 'car';
      cars[i].certOwner = clientCertId;
      await ctx.stub.putState('CAR' + i, Buffer.from(JSON.stringify(cars[i])));
      console.info('Added <--> ', cars[i]);
    }
    console.info('============= END : Initialize Ledger ===========');
  }

  // @Transaction(false)
  // @Returns('boolean')
  public async carExists(ctx: Context, carNumber: string): Promise<boolean> {

    // make sure the carNumber is valid before trying to get it
    Utils.verifyCarKey(carNumber);

    const buffer = await ctx.stub.getState(carNumber);
    return (!!buffer && buffer.length > 0);
  }

  @Transaction()
  @Returns('Car')
  public async queryCar(ctx: Context, carNumber: string): Promise<Car> {

    // Check for a transient option to control output. We allow:
    // [ "QueryOutput": "all" | "normal" (the default) ] Returns certOwner field in the output
    let outputAll = false;
    const transientData = ctx.stub.getTransient();
    if (transientData.has('QueryOutput')) {
      const value = transientData.get('QueryOutput');
      if (value.toString('utf8') === 'all') {
        outputAll = true;
      }
    }

    const exists = await this.carExists(ctx, carNumber);
    if (!exists) {
      throw new Error(`The car ${carNumber} does not exist.`);
    }

    const buffer = await ctx.stub.getState(carNumber); // get the car from chaincode state
    const car = JSON.parse(buffer.toString()) as Car;
    if (!outputAll) {
      car.certOwner = undefined; // remove before returning to user
    }
    return car;
  }

  @Transaction()
  @Returns('object[]')
  public async queryAllCars(ctx: Context): Promise<object[]> {

    // Check for transient options to control query and output. We allow:
    // 1: [ "QueryOutput": "all" | "normal" (the default) ] Returns certOwner field in the output
    // 2: [ "QueryByOwner": "John" ] Return only those cars owned by "John" or "Max" or whoever
    // 3: [ "QueryByCreator": "true" | "fabric_user_xxxx" ] Returns only cars the caller (or another user) have created and have not transfered
    // 4: [ "QueryOutput": "all", "QueryByOwner": "John", "QueryByCreator": "true" ] Combinations of the above
    let outputAll = false;
    let iterator: Iterators.StateQueryIterator; // undefined
    const transientData = ctx.stub.getTransient();
    const optionsCount = transientData.size;
    if (optionsCount > 0) {
      // store the index and design doc to use
      let queryIndexName = '';
      let queryIndexDesignDocName = '';

      // Get output options
      if (transientData.has('QueryOutput')) {
        const value = transientData.get('QueryOutput');
        if (value.toString('utf8') === 'all') {
          outputAll = true;
        }

        // set up the correct index to use in the search
        queryIndexName = 'indexDocType';
        queryIndexDesignDocName = '_design/indexDocTypeDoc';
      }

      let queryByOwner = '';
      const selector: any = {};
      // Process queryByOwner options
      if (transientData.has('QueryByOwner')) {
        const value = transientData.get('QueryByOwner');
        queryByOwner = value.toString('utf8');

        // set up the correct index to use in the search
        queryIndexName = 'indexOwner';
        queryIndexDesignDocName = '_design/indexOwnerDoc';

        // set up the correct selector to use in the search
        selector.owner = queryByOwner;
      }

      // Process query by Creator options
      // Note: if owner and certOwner are choses it will work but will
      // slow down the search as we do not index for owner AND certOwner together
      if (transientData.has('QueryByCreator')) {
        const value = transientData.get('QueryByCreator');
        const creatorId = value.toString('utf8');

        // get our ID to queryBy or use as a template
        const cid = new ClientIdentity(ctx.stub);
        const clientCertId = cid.getID();

        // true means use current callers ID
        let queryByCreatorId = '';
        if (creatorId === 'true') {
          queryByCreatorId = clientCertId;
        } else if (creatorId.startsWith('x509::/')) {
          // explicit string used, use this verbatim
          queryByCreatorId = creatorId;
        } else {
          // Replace current caller CN with the provided one. This only works
          // for cars that are created under the using the same CA as the caller.
          queryByCreatorId = Utils.replaceCN(clientCertId, creatorId);
        }

        // set up the correct index to use in the search
        queryIndexName = 'indexCertOwner';
        queryIndexDesignDocName = '_design/indexCertOwnerDoc';

        // set up the correct selector to use in the search
        selector.certOwner = queryByCreatorId;
      }

      // construct the query
      selector.docType = 'car';
      const query = {
        selector,
        use_index: [
          queryIndexDesignDocName,
          queryIndexName,
        ],
      };
      console.log('****QUERY: ', query);

      // finally issue the query
      iterator = await ctx.stub.getQueryResult(JSON.stringify(query));

    } else {
      // process a simple range query instead
      const startKey = 'CAR0';
      const endKey = 'CAR9999';

      // issue the query
      iterator = await ctx.stub.getStateByRange(startKey, endKey);
    }

    // Now process the query results
    const allResults: object[] = [];
    while (true) {
      const result = await iterator.next();

      if (result.value) {
        // console.log(res.value.value.toString('utf8'));

        const key = result.value.key;
        let car: Car;
        try {
          car = JSON.parse(result.value.value.toString('utf8')) as Car;
          if (!outputAll) {
            car.certOwner = undefined; // remove before returning to user
          }
        } catch (err) {
          console.log(err);
          // car = result.value.value.toString('utf8');
          throw new Error(`The car ${key} has an invalid JSON record ${result.value.value.toString('utf8')}.`);
        }
        allResults.push({ key, car });
      }

      if (result.done) {
        // console.log('end of data');
        await iterator.close();
        console.info(allResults);
        return allResults;
      }
    }
  }

  @Transaction()
  public async createCar(ctx: Context, carNumber: string, make: string, model: string, color: string, owner: string) {
    console.info('============= START : Create Car ===========');

    const exists = await this.carExists(ctx, carNumber);
    if (exists) {
      throw new Error(`The car ${carNumber} already exists.`);
    }

    // get our ID to stamp into the car
    const cid = new ClientIdentity(ctx.stub);
    const clientCertId = cid.getID();

    // Special case CAR10 as it's a reserved slot for IBM Org.
    // So are CAR0 - CAR9, but because initLedger created those cars, they will already exist...
    if (carNumber === 'CAR10') {
      const msp = cid.getMSPID();
      if (msp !== 'IBMMSP') {
        const clientCN = Utils.extractCN(clientCertId);
        throw new Error(`The car ${carNumber} cannot be created. User ${clientCN} not authorised to create a car with reserved ID 'CAR10'.`);
      }
    }

    // Limit the total cars a single user can create to maxCars.
    // As we have to search to find cars owned by the current caller,
    // we construct the query to return the minimum data - not actual cars
    const maxCars = 20;
    const query = {
      fields: ['_id'],
      selector: {
        certOwner: clientCertId,
        docType: 'car',
      },
      use_index: [
        '_design/indexCertOwnerDoc',
        'indexCertOwner',
      ],
    };

    const iter = await ctx.stub.getQueryResult(JSON.stringify(query));
    let carCount = 0;
    while (true) {
      // count results only - ignore contents
      const res = await iter.next();
      if (res.value) { ++carCount; }
      if (res.done) { await iter.close(); break; }
    }

    if (carCount >= maxCars) {
      const msp = cid.getMSPID();
      if (msp !== 'IBMMSP') {
        const clientCN = Utils.extractCN(clientCertId);
        throw new Error(`The car ${carNumber} cannot be created. User ${clientCN} is not authorised to create more than ${maxCars} cars.`);
      }
    }

    const car: Car = {
      certOwner: clientCertId,
      color,
      docType: 'car',
      make,
      model,
      owner,
    };

    const buffer = Buffer.from(JSON.stringify(car));
    await ctx.stub.putState(carNumber, buffer);

    console.info('============= END : Create Car ===========');
  }

  @Transaction()
  public async deleteCar(ctx: Context, carNumber: string) {
    console.info('============= START : Delete Car ===========');

    const exists = await this.carExists(ctx, carNumber);
    if (!exists) {
      throw new Error(`The car ${carNumber} does not exist.`);
    }

    // get the car we want to modify and the current certOwner from it
    const buffer = await ctx.stub.getState(carNumber); // get the car from chaincode state
    const car = JSON.parse(buffer.toString()) as Car;
    const carCertId = car.certOwner;

    // get the client ID so we can make sure they are allowed to modify the car
    const cid = new ClientIdentity(ctx.stub);
    const clientCertId = cid.getID();

    // The rule is to be able to delete a car you must be the current certOwner for it
    // which usually means you are the creater of it or have had it transfered to your FabricUserID (CN)
    // Note we allow underfined for now as we may be deployed on an older ledger which did not put clientCertId into cars...
    if (carCertId !== undefined) {
      if (carCertId !== clientCertId) {

        // we are not the certOwner for it, but see if it has been transfered to us via a
        // changeCarOwner() transaction - which means we check our CN against the external current owner
        const clientCN = Utils.extractCN(clientCertId);
        if (clientCN !== car.owner) {
          // special case IBM Org which can delete anything
          const msp = cid.getMSPID();
          if (msp !== 'IBMMSP') {
            const carCN = Utils.extractCN(carCertId);
            throw new Error(`The car ${carNumber} cannot be deleted. User ${clientCN} not authorised to delete car owned by ${carCN}.`);
          }
        }
      }
    }

    await ctx.stub.deleteState(carNumber);
    console.info('============= END : Delete Car ===========');
  }

  @Transaction()
  public async changeCarOwner(ctx: Context, carNumber: string, newOwner: string) {
    console.info('============= START : changeCarOwner ===========');

    const exists = await this.carExists(ctx, carNumber);
    if (!exists) {
      throw new Error(`The car ${carNumber} does not exist.`);
    }

    // get the car we want to modify and the current certOwner from it
    const buffer = await ctx.stub.getState(carNumber); // get the car from chaincode state
    const car = JSON.parse(buffer.toString()) as Car;
    const carCertId = car.certOwner;

    // get the client ID so we can make sure they are allowed to modify the car
    const cid = new ClientIdentity(ctx.stub);
    const clientCertId = cid.getID();

    // the rule is to be able to modify a car you must be the current certOwner for it
    // which usually means you are the creater of it or have had it transfered to your FabricUserID (CN)
    if (carCertId !== clientCertId) {

      // we are not the certOwner for it, but see if it has been transfered to us via a
      // changeCarOwner() transaction - which means we check our CN against the current external owner
      const clientCN = Utils.extractCN(clientCertId);
      if (clientCN !== car.owner) {
        // special case IBM Org which can take ownership of anything
        const msp = cid.getMSPID();
        if (msp !== 'IBMMSP') {
          const carCN = Utils.extractCN(carCertId);
          throw new Error(`The ownership of car ${carNumber} cannot be changed. User ${clientCN} not authorised to change a car owned by ${carCN}.`);
        }
      } else {
        // as the car has been transfered to us, we need to take "full" ownership of it
        // this prevents the previous owner deleting it for example. IBM Org does not need to do this!
        car.certOwner = clientCertId;
      }
    }

    // set the new owner into the car
    const previousOwner = car.owner;
    car.owner = newOwner;

    // put the car into the RWSET for adding to the ledger
    await ctx.stub.putState(carNumber, Buffer.from(JSON.stringify(car)));

    // emit an event to inform listeners that a car has had its owner changed
    const changeOwnerEvent = new ChangeOwnerEvent(carNumber, previousOwner, newOwner);
    ctx.stub.setEvent(changeOwnerEvent.docType, Buffer.from(JSON.stringify(changeOwnerEvent)));

    console.info('============= END : changeCarOwner ===========');
  }

  @Transaction()
  @Returns('PreviousOwnersResult')
  public async getPreviousOwners(ctx: Context, carNumber: string): Promise<PreviousOwnersResult> {
    console.info('============= START : getPreviousOwners ===========');

    const exists = await this.carExists(ctx, carNumber);
    if (!exists) {
      throw new Error(`The car ${carNumber} does not exist.`);
    }

    const historyIterator = await ctx.stub.getHistoryForKey(carNumber);
    const previousOwners: string[] = [];
    const previousOwnershipChangeDates: Date[] = [];
    let previousOwnerCount = 0;
    let currentOwner: string;
    let currentOwnershipChangeDate: Date;
    while (true) {
      const res = await historyIterator.next();
      if (res.value) {
        let result: string;
        let txnDate: Date;
        if (res.value.is_delete) {
          result = 'CAR KEY DELETED';
          const txnTs = res.value.getTimestamp();
          txnDate = TimestampMapper.toDate(txnTs);
        } else {
          // console.log(res.value.value.toString('utf8'));
          try {
            const car = JSON.parse(res.value.value.toString('utf8')) as Car;
            result = car.owner;
            ++previousOwnerCount;
            const txnTs = res.value.getTimestamp();
            txnDate = TimestampMapper.toDate(txnTs);
          } catch (err) {
            console.log(err);
            // result = 'Invalid JSON';
            console.log(err);
            throw new Error(`The car ${carNumber} has an invalid JSON record ${res.value.value.toString('utf8')}.`);
          }
        }
        if (res.done) {
          // keep current owner out of previousOwner list
          --previousOwnerCount;
          currentOwner = result;
          currentOwnershipChangeDate = txnDate;
        } else {
          previousOwners.push(result);
          previousOwnershipChangeDates.push(txnDate);
        }
      }
      if (res.done) {
        // console.log('end of data');
        await historyIterator.close();
        break;
      }
    }

    // create the return data
    const allresults = new PreviousOwnersResult(
      previousOwnerCount,
      previousOwners,
      previousOwnershipChangeDates,
      currentOwner,
      currentOwnershipChangeDate,
    );

    console.info('============= END : getPreviousOwners ===========');
    return allresults;
  }

  @Transaction()
  public async confirmTransfer(ctx: Context, carNumber: string): Promise<boolean> {
    console.info('============= START : confirmTransfer ===========');

    const exists = await this.carExists(ctx, carNumber);
    if (!exists) {
      throw new Error(`The car ${carNumber} does not exist.`);
    }

    // get the car we want to modify and the current certOwner from it
    const buffer = await ctx.stub.getState(carNumber); // get the car from chaincode state
    const car = JSON.parse(buffer.toString()) as Car;
    const carCertId = car.certOwner;

    // get the client ID so we can make sure they are allowed to modify the car
    const cid = new ClientIdentity(ctx.stub);
    const clientCertId = cid.getID();

    // the rule is to be able to modify a car you must be the current certOwner for it
    // which usually means you are the creater of it or have had it transfered to your FabricUserID (CN)
    // However, here we are bypassing this so we want to make sure that our clientID is NOT sure certOwner,
    // but that our clientCN IS the external owner
    if (carCertId === clientCertId) {
      // no transfer takes place - we are already the owner
      return false;
    }

    // we are not the certOwner for it (good), but make sure it has been transfered to us via a
    // changeCarOwner() transaction - which means we check our CN against the current external owner
    const clientCN = Utils.extractCN(clientCertId);
    if (clientCN === car.owner) {
      // as the car has been transfered to us, we need to take "full" ownership of it
      // this prevents the previous owner deleting it for example.
      car.certOwner = clientCertId;
    } else {
      // not transfered to us
      const carCN = Utils.extractCN(carCertId);
      throw new Error(`The ownership of car ${carNumber} cannot be changed. User ${carCN} has not authorised ${clientCN} to take ownership.`);
    }

    await ctx.stub.putState(carNumber, Buffer.from(JSON.stringify(car)));

    console.info('============= END : confirmTransfer ===========');
    return true;
  }
}
